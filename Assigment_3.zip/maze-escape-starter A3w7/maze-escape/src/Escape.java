import java.util.Arrays;

/**
 * Mission 3. Escape: iterative DFS from cell 0 to the last cell.
 */
public class Escape {

    /**
     * path: the cells of the way out, from 0 to the last cell.
     * visited: how many cells are marked as visited at the moment the exit is marked.
     * deadEnds: how many cells have exactly one open neighbour.
     */
    public record Result(int[] path, int visited, int deadEnds) {}

    public static Result escape(Input.Walls w, int[] broken) {
        int n = w.cells();
        if (n == 0) {
            return new Result(new int[0], 0, 0);
        }

        int cols = w.cols();
        int[][] g = Graphs.open(w, broken);

        int deadEnds = 0;
        for (int i = 0; i < n; i++) {
            if (g[i].length == 1) {
                deadEnds++;
            }
        }

        int start = 0;
        int exit = n - 1;

        if (start == exit) {
            return new Result(new int[]{start}, 1, deadEnds);
        }

        boolean[] visited = new boolean[n];
        int[] parent = new int[n];
        Arrays.fill(parent, -2);

        int[] stackCell = new int[n];
        int[] stackDir = new int[n];

        int top = 0;
        stackCell[0] = start;
        stackDir[0] = 0;

        visited[start] = true;
        parent[start] = -1;
        int visitedCount = 1;

        while (top >= 0) {
            int v = stackCell[top];
            int dir = stackDir[top];

            if (dir == 4) {
                top--;
                continue;
            }

            stackDir[top] = dir + 1;

            int u = neighbour(v, dir, cols, n);
            if (u < 0 || visited[u]) continue;
            if (!isOpen(g[v], u)) continue;

            visited[u] = true;
            visitedCount++;
            parent[u] = v;

            if (u == exit) {
                int len = 0;
                for (int x = exit; x != -1; x = parent[x]) {
                    len++;
                }

                int[] path = new int[len];
                int idx = len - 1;
                for (int x = exit; x != -1; x = parent[x]) {
                    path[idx--] = x;
                }

                return new Result(path, visitedCount, deadEnds);
            }

            top++;
            stackCell[top] = u;
            stackDir[top] = 0;
        }

        return new Result(new int[0], visitedCount, deadEnds);
    }

    /**
     * Order: 0 = up, 1 = right, 2 = down, 3 = left.
     */
    private static int neighbour(int v, int dir, int cols, int n) {
        switch (dir) {
            case 0: // up
                return v - cols >= 0 ? v - cols : -1;
            case 1: // right
                return (v % cols != cols - 1 && v + 1 < n) ? v + 1 : -1;
            case 2: // down
                return v + cols < n ? v + cols : -1;
            case 3: // left
                return v % cols != 0 ? v - 1 : -1;
            default:
                return -1;
        }
    }

    private static boolean isOpen(int[] neighbours, int target) {
        for (int u : neighbours) {
            if (u == target) return true;
        }
        return false;
    }
}