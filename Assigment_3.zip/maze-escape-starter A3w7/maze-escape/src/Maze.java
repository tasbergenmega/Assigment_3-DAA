import java.util.Arrays;

/**
 * Missions 1 and 2. Building the maze out of the walls.
 */
public class Maze {

    /**
     * Mission 1. Take the walls in the order of the file.
     * Break a wall when its two cells are in different sets.
     */
    public static int[] breakWalls(Input.Walls w) {
        int[] result = new int[w.count()];
        int cnt = 0;
        DisjointSet dsu = new DisjointSet(w.cells());

        for (int k = 0; k < w.count(); k++) {
            if (dsu.union(w.a()[k], w.b()[k])) {
                result[cnt++] = k;
            }
        }

        return Arrays.copyOf(result, cnt);
    }

    /**
     * Mission 2. Kruskal: take the walls from the cheapest to the most expensive.
     */
    public static int[] cheapestMaze(Input.Walls w) {
        int m = w.count();
        long[] edges = new long[m];

        for (int i = 0; i < m; i++) {
            // high 32 bits: cost, low 32 bits: wall index
            edges[i] = ((long) w.cost()[i] << 32) | (i & 0xffffffffL);
        }
        Arrays.sort(edges);

        int[] result = new int[w.cells() - 1];
        int cnt = 0;
        DisjointSet dsu = new DisjointSet(w.cells());

        for (long e : edges) {
            int k = (int) (e & 0xffffffffL);
            if (dsu.union(w.a()[k], w.b()[k])) {
                result[cnt++] = k;
                if (cnt == result.length) break;
            }
        }

        return Arrays.copyOf(result, cnt);
    }

    /**
     * Mission 2. Prim with a priority queue.
     * Returns the total cost of the cheapest maze.
     */
    public static long primCost(Input.Walls w) {
        int n = w.cells();
        if (n == 0) return 0;

        int m = w.count();
        int[] head = new int[n];
        Arrays.fill(head, -1);

        int[] to = new int[2 * m];
        int[] next = new int[2 * m];
        int[] cost = new int[2 * m];
        int edgeCount = 0;

        for (int k = 0; k < m; k++) {
            int a = w.a()[k];
            int b = w.b()[k];
            int c = w.cost()[k];

            to[edgeCount] = b;
            cost[edgeCount] = c;
            next[edgeCount] = head[a];
            head[a] = edgeCount++;

            to[edgeCount] = a;
            cost[edgeCount] = c;
            next[edgeCount] = head[b];
            head[b] = edgeCount++;
        }

        boolean[] used = new boolean[n];
        LongMinHeap pq = new LongMinHeap(16);
        pq.push(pack(0, 0));

        long total = 0;
        int usedCount = 0;

        while (!pq.isEmpty() && usedCount < n) {
            long cur = pq.pop();
            int v = (int) (cur & 0xffffffffL);
            int c = (int) (cur >>> 32);

            if (used[v]) continue;

            used[v] = true;
            total += c;
            usedCount++;

            for (int e = head[v]; e != -1; e = next[e]) {
                int u = to[e];
                if (!used[u]) {
                    pq.push(pack(cost[e], u));
                }
            }
        }

        return total;
    }

    private static long pack(int cost, int vertex) {
        return ((long) cost << 32) | (vertex & 0xffffffffL);
    }

    private static class LongMinHeap {
        private long[] heap;
        private int size;

        LongMinHeap(int capacity) {
            heap = new long[Math.max(16, capacity + 1)];
            size = 0;
        }

        boolean isEmpty() {
            return size == 0;
        }

        void push(long value) {
            if (size + 1 >= heap.length) {
                heap = Arrays.copyOf(heap, heap.length * 2);
            }

            heap[++size] = value;
            int i = size;

            while (i > 1) {
                int p = i / 2;
                if (heap[p] <= heap[i]) break;
                long t = heap[p];
                heap[p] = heap[i];
                heap[i] = t;
                i = p;
            }
        }

        long pop() {
            long result = heap[1];
            heap[1] = heap[size--];

            int i = 1;
            while (true) {
                int left = 2 * i;
                if (left > size) break;

                int right = left + 1;
                int min = left;

                if (right <= size && heap[right] < heap[left]) {
                    min = right;
                }

                if (heap[i] <= heap[min]) break;

                long t = heap[i];
                heap[i] = heap[min];
                heap[min] = t;
                i = min;
            }

            return result;
        }
    }
}