import java.util.Arrays;

/**
 * Missions 4 and 5. Zones and fastest route.
 */
public class Zones {

    /**
     * Mission 4. Kosaraju. Returns zoneOf[cell] = zone number.
     */
    public static int[] kosaraju(Input.Slides s) {
        int n = s.n();
        int[][] from = Graphs.slidesFrom(s);
        int[][] into = Graphs.slidesInto(s);

        boolean[] seen = new boolean[n];
        int[] order = new int[n];
        int orderSize = 0;

        int[] stack = new int[n];
        int[] iter = new int[n];

        // First pass: original graph, write finish order.
        for (int start = 0; start < n; start++) {
            if (seen[start]) continue;

            int top = 0;
            stack[0] = start;
            iter[0] = 0;
            seen[start] = true;

            while (top >= 0) {
                int v = stack[top];

                if (iter[top] < from[v].length) {
                    int slide = from[v][iter[top]++];
                    int u = s.to()[slide];

                    if (!seen[u]) {
                        seen[u] = true;
                        top++;
                        stack[top] = u;
                        iter[top] = 0;
                    }
                } else {
                    order[orderSize++] = v;
                    top--;
                }
            }
        }

        // Second pass: reversed graph, in reverse finish order.
        int[] zoneOf = new int[n];
        Arrays.fill(zoneOf, -1);

        int zoneCount = 0;

        for (int i = orderSize - 1; i >= 0; i--) {
            int start = order[i];
            if (zoneOf[start] != -1) continue;

            int top = 0;
            stack[0] = start;
            zoneOf[start] = zoneCount;

            while (top >= 0) {
                int v = stack[top--];

                for (int slide : into[v]) {
                    int u = s.from()[slide];

                    if (zoneOf[u] == -1) {
                        zoneOf[u] = zoneCount;
                        stack[++top] = u;
                    }
                }
            }

            zoneCount++;
        }

        return zoneOf;
    }

    /**
     * Mission 5.
     * [0] flow stages: number of zones on the longest chain;
     * [1] cheapest route from the zone of cell 0 to the zone of the last cell.
     */
    public static long[] routes(Input.Slides s, int[] zoneOf, int zoneCount) {
        if (s.n() == 0 || zoneCount == 0) {
            return new long[]{0, 0};
        }

        int slideCount = s.count();

        int[] head = new int[zoneCount];
        Arrays.fill(head, -1);

        int[] to = new int[slideCount];
        int[] cost = new int[slideCount];
        int[] next = new int[slideCount];

        int edgeCount = 0;

        for (int i = 0; i < slideCount; i++) {
            int zu = zoneOf[s.from()[i]];
            int zv = zoneOf[s.to()[i]];

            if (zu != zv) {
                to[edgeCount] = zv;
                cost[edgeCount] = s.time()[i];
                next[edgeCount] = head[zu];
                head[zu] = edgeCount++;
            }
        }

        // Flow stages: longest chain of zones.
        int[] flow = new int[zoneCount];
        Arrays.fill(flow, 1);

        int maxFlow = 1;

        for (int z = 0; z < zoneCount; z++) {
            for (int e = head[z]; e != -1; e = next[e]) {
                int w = to[e];

                if (flow[w] < flow[z] + 1) {
                    flow[w] = flow[z] + 1;
                    if (flow[w] > maxFlow) {
                        maxFlow = flow[w];
                    }
                }
            }
        }

        // Fastest route in the zone graph.
        int startZone = zoneOf[0];
        int exitZone = zoneOf[s.n() - 1];

        long INF = Long.MAX_VALUE / 4;
        long[] dist = new long[zoneCount];
        Arrays.fill(dist, INF);
        dist[startZone] = 0;

        for (int z = 0; z < zoneCount; z++) {
            if (dist[z] == INF) continue;

            for (int e = head[z]; e != -1; e = next[e]) {
                int w = to[e];
                long nd = dist[z] + cost[e];

                if (nd < dist[w]) {
                    dist[w] = nd;
                }
            }
        }

        return new long[]{maxFlow, dist[exitZone]};
    }
}